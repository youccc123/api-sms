create function bpcharnlike(character, text) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$textnlike$$;

comment on function bpcharnlike(char, text) is 'implementation of !~~ operator';

alter function bpcharnlike(char, text) owner to postgres;


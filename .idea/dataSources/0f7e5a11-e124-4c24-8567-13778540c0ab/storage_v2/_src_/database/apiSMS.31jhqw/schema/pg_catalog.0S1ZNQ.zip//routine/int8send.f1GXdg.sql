create function int8send(bigint) returns bytea
    immutable
    strict
    cost 1
    language internal
as
$$int8send$$;

comment on function int8send(bigint) is 'I/O';

alter function int8send(bigint) owner to postgres;


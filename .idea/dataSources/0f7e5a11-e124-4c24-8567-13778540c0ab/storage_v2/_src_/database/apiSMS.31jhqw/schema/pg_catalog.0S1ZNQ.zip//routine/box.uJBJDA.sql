create function box(polygon) returns box
    immutable
    strict
    cost 1
    language internal
as
$$poly_box$$;

comment on function box(polygon, point) is 'convert polygon to bounding box';

alter function box(polygon, point) owner to postgres;


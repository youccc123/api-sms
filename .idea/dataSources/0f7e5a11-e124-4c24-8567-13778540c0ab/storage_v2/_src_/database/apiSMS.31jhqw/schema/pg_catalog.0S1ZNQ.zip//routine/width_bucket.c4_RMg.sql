create function width_bucket(double precision, double precision, double precision, integer) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$width_bucket_float8$$;

comment on function width_bucket(numeric, numeric, numeric, integer) is 'bucket number of operand in equidepth histogram';

alter function width_bucket(numeric, numeric, numeric, integer) owner to postgres;


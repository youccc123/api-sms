create function ceiling(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$dceil$$;

comment on function ceiling(double precision) is 'smallest integer >= value';

alter function ceiling(double precision) owner to postgres;


create function abstime(timestamp without time zone) returns abstime
    immutable
    strict
    cost 1
    language internal
as
$$timestamp_abstime$$;

comment on function abstime(timestamp with time zone) is 'convert timestamp with time zone to abstime';

alter function abstime(timestamp with time zone) owner to postgres;


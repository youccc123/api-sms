create function bpcharlike(character, text) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$textlike$$;

comment on function bpcharlike(char, text) is 'implementation of ~~ operator';

alter function bpcharlike(char, text) owner to postgres;


create function timestamptz_send(timestamp with time zone) returns bytea
    immutable
    strict
    cost 1
    language internal
as
$$timestamptz_send$$;

comment on function timestamptz_send(timestamp with time zone) is 'I/O';

alter function timestamptz_send(timestamp with time zone) owner to postgres;


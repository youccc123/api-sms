create function array_upper(anyarray, integer) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$array_upper$$;

comment on function array_upper(anyarray, integer) is 'array upper dimension';

alter function array_upper(anyarray, integer) owner to postgres;


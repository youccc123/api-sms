create function gist_box_consistent(internal, box, integer, oid, internal) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$gist_box_consistent$$;

comment on function gist_box_consistent(internal, box, integer, oid, internal) is 'GiST support';

alter function gist_box_consistent(internal, box, integer, oid, internal) owner to postgres;


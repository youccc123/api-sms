create function bool_accum(internal, boolean) returns internal
    immutable
    cost 1
    language internal
as
$$bool_accum$$;

comment on function bool_accum(internal, boolean) is 'aggregate transition function';

alter function bool_accum(internal, boolean) owner to postgres;


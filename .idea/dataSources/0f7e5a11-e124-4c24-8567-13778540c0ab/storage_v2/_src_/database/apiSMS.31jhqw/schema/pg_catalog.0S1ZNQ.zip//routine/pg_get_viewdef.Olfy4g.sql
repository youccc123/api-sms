create function pg_get_viewdef(text) returns text
    stable
    strict
    cost 1
    language internal
as
$$pg_get_viewdef_name$$;

comment on function pg_get_viewdef(oid, integer) is 'select statement of a view with pretty-printing and specified line wrapping';

alter function pg_get_viewdef(oid, integer) owner to postgres;


create function rtrim(text) returns text
    immutable
    strict
    cost 1
    language internal
as
$$rtrim1$$;

comment on function rtrim(text, text) is 'trim spaces from right end of string';

alter function rtrim(text, text) owner to postgres;


create function has_server_privilege(name, text, text) returns boolean
    stable
    strict
    cost 1
    language internal
as
$$has_server_privilege_name_name$$;

comment on function has_server_privilege(text, text, text) is 'current user privilege on server by server name';

alter function has_server_privilege(text, text, text) owner to postgres;


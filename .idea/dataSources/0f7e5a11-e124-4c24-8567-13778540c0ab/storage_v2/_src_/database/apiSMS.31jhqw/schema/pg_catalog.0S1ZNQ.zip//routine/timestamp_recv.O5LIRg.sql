create function timestamp_recv(internal, oid, integer) returns timestamp without time zone
    immutable
    strict
    cost 1
    language internal
as
$$timestamp_recv$$;

comment on function timestamp_recv(internal, oid, integer) is 'I/O';

alter function timestamp_recv(internal, oid, integer) owner to postgres;


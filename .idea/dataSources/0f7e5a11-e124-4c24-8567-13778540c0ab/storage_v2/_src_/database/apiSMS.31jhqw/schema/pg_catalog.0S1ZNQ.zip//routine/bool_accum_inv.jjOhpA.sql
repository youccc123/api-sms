create function bool_accum_inv(internal, boolean) returns internal
    immutable
    cost 1
    language internal
as
$$bool_accum_inv$$;

comment on function bool_accum_inv(internal, boolean) is 'aggregate transition function';

alter function bool_accum_inv(internal, boolean) owner to postgres;


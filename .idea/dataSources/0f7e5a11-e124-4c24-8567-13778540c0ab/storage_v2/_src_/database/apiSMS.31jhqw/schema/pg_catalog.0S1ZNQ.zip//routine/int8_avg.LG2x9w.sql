create function int8_avg(bigint[]) returns numeric
    immutable
    strict
    cost 1
    language internal
as
$$int8_avg$$;

comment on function int8_avg(bigint[]) is 'aggregate final function';

alter function int8_avg(bigint[]) owner to postgres;


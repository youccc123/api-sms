create function icregexeqjoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    cost 1
    language internal
as
$$icregexeqjoinsel$$;

comment on function icregexeqjoinsel(internal, oid, internal, smallint, internal) is 'join selectivity of case-insensitive regex match';

alter function icregexeqjoinsel(internal, oid, internal, smallint, internal) owner to postgres;


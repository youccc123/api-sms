create function interval_recv(internal, oid, integer) returns interval
    immutable
    strict
    cost 1
    language internal
as
$$interval_recv$$;

comment on function interval_recv(internal, oid, integer) is 'I/O';

alter function interval_recv(internal, oid, integer) owner to postgres;


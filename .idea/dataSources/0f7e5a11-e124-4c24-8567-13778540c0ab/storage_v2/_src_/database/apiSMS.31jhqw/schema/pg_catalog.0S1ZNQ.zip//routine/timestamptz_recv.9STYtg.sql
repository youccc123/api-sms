create function timestamptz_recv(internal, oid, integer) returns timestamp with time zone
    immutable
    strict
    cost 1
    language internal
as
$$timestamptz_recv$$;

comment on function timestamptz_recv(internal, oid, integer) is 'I/O';

alter function timestamptz_recv(internal, oid, integer) owner to postgres;


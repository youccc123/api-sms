create function pg_read_file(text) returns text
    strict
    cost 1
    language internal
as
$$pg_read_file_all$$;

comment on function pg_read_file(text, bigint, bigint) is 'read text from a file';

alter function pg_read_file(text, bigint, bigint) owner to postgres;


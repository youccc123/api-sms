create function pg_advisory_unlock_shared(bigint) returns boolean
    strict
    cost 1
    language internal
as
$$pg_advisory_unlock_shared_int8$$;

comment on function pg_advisory_unlock_shared(bigint, int4) is 'release shared advisory lock';

alter function pg_advisory_unlock_shared(bigint, int4) owner to postgres;


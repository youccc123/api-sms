create function networkjoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    cost 1
    language internal
as
$$networkjoinsel$$;

comment on function networkjoinsel(internal, oid, internal, smallint, internal) is 'join selectivity for network operators';

alter function networkjoinsel(internal, oid, internal, smallint, internal) owner to postgres;


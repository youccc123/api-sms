create function date_trunc(text, timestamp without time zone) returns timestamp without time zone
    immutable
    strict
    cost 1
    language internal
as
$$timestamp_trunc$$;

comment on function date_trunc(text, interval) is 'truncate interval to specified units';

alter function date_trunc(text, interval) owner to postgres;


create function pg_try_advisory_lock(bigint) returns boolean
    strict
    cost 1
    language internal
as
$$pg_try_advisory_lock_int8$$;

comment on function pg_try_advisory_lock(bigint, int4) is 'obtain exclusive advisory lock if available';

alter function pg_try_advisory_lock(bigint, int4) owner to postgres;


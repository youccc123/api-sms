create function hashfloat4(real) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$hashfloat4$$;

comment on function hashfloat4(real) is 'hash';

alter function hashfloat4(real) owner to postgres;


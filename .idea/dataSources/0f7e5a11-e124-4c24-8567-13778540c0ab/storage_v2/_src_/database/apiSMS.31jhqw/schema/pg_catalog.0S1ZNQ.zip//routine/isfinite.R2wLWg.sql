create function isfinite(abstime) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$abstime_finite$$;

comment on function isfinite(timestamp with time zone) is 'finite timestamp?';

alter function isfinite(timestamp with time zone) owner to postgres;


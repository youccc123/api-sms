create function format(text) returns text
    stable
    cost 1
    language internal
as
$$text_format_nv$$;

comment on function format(text, "any") is 'format text message';

alter function format(text, "any") owner to postgres;


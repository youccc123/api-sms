create function array_length(anyarray, integer) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$array_length$$;

comment on function array_length(anyarray, integer) is 'array length';

alter function array_length(anyarray, integer) owner to postgres;


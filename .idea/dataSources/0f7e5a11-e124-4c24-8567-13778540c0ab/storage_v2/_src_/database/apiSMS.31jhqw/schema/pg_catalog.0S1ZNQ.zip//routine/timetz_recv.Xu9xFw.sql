create function timetz_recv(internal, oid, integer) returns time with time zone
    immutable
    strict
    cost 1
    language internal
as
$$timetz_recv$$;

comment on function timetz_recv(internal, oid, integer) is 'I/O';

alter function timetz_recv(internal, oid, integer) owner to postgres;


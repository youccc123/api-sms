create function pg_get_ruledef(oid) returns text
    stable
    strict
    cost 1
    language internal
as
$$pg_get_ruledef$$;

comment on function pg_get_ruledef(oid, boolean) is 'source text of a rule with pretty-print option';

alter function pg_get_ruledef(oid, boolean) owner to postgres;


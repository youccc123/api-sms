create function abstime(timestamp without time zone) returns abstime
    stable
    strict
    cost 1
    language internal
as
$$timestamp_abstime$$;

comment on function abstime(timestamp) is 'convert timestamp to abstime';

alter function abstime(timestamp) owner to postgres;


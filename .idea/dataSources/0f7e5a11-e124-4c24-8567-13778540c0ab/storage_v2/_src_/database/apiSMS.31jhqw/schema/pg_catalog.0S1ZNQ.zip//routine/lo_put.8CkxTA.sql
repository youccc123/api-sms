create function lo_put(oid, bigint, bytea) returns void
    strict
    cost 1
    language internal
as
$$lo_put$$;

comment on function lo_put(oid, bigint, bytea) is 'write data at offset';

alter function lo_put(oid, bigint, bytea) owner to postgres;


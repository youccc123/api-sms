create function boolout(boolean) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$boolout$$;

comment on function boolout(boolean) is 'I/O';

alter function boolout(boolean) owner to postgres;


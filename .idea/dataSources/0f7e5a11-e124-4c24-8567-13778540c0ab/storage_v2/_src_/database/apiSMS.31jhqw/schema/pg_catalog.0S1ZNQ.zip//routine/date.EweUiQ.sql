create function date(abstime) returns date
    immutable
    strict
    cost 1
    language internal
as
$$abstime_date$$;

comment on function date(timestamp) is 'convert timestamp to date';

alter function date(timestamp) owner to postgres;


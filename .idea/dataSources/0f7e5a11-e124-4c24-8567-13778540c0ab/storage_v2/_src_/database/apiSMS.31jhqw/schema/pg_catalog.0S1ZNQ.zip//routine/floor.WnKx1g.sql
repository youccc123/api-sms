create function floor(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$dfloor$$;

comment on function floor(double precision) is 'largest integer <= value';

alter function floor(double precision) owner to postgres;


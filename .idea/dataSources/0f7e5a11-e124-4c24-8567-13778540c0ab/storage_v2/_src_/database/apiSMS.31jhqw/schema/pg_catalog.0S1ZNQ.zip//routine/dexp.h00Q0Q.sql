create function dexp(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$dexp$$;

comment on function dexp(double precision) is 'natural exponential (e^x)';

alter function dexp(double precision) owner to postgres;


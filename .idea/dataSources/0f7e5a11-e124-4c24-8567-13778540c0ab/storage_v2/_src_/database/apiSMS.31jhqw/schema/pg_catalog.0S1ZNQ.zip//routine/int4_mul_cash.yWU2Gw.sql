create function int4_mul_cash(integer, money) returns money
    immutable
    strict
    cost 1
    language internal
as
$$int4_mul_cash$$;

comment on function int4_mul_cash(integer, money) is 'implementation of * operator';

alter function int4_mul_cash(integer, money) owner to postgres;


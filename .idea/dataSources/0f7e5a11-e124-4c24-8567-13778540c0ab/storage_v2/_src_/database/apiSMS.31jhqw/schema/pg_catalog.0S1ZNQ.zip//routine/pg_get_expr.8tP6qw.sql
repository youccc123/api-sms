create function pg_get_expr(pg_node_tree, oid) returns text
    stable
    strict
    cost 1
    language internal
as
$$pg_get_expr$$;

comment on function pg_get_expr(pg_node_tree, oid, boolean) is 'deparse an encoded expression with pretty-print option';

alter function pg_get_expr(pg_node_tree, oid, boolean) owner to postgres;


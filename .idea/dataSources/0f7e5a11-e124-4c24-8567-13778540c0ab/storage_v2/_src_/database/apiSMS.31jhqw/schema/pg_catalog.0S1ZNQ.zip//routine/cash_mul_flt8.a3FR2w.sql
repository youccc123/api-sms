create function cash_mul_flt8(money, double precision) returns money
    immutable
    strict
    cost 1
    language internal
as
$$cash_mul_flt8$$;

comment on function cash_mul_flt8(money, double precision) is 'implementation of * operator';

alter function cash_mul_flt8(money, double precision) owner to postgres;


create function timetz_send(time with time zone) returns bytea
    immutable
    strict
    cost 1
    language internal
as
$$timetz_send$$;

comment on function timetz_send(time with time zone) is 'I/O';

alter function timetz_send(time with time zone) owner to postgres;


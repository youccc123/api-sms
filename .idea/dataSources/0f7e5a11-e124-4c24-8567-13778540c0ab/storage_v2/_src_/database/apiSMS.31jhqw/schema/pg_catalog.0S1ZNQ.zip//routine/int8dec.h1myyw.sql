create function int8dec(bigint) returns bigint
    immutable
    strict
    cost 1
    language internal
as
$$int8dec$$;

comment on function int8dec(bigint) is 'decrement';

alter function int8dec(bigint) owner to postgres;


create function oid(bigint) returns oid
    immutable
    strict
    cost 1
    language internal
as
$$i8tooid$$;

comment on function oid(bigint) is 'convert int8 to oid';

alter function oid(bigint) owner to postgres;


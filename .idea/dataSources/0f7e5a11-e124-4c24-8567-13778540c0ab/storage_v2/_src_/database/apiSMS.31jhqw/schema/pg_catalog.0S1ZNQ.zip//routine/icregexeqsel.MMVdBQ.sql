create function icregexeqsel(internal, oid, internal, integer) returns double precision
    stable
    strict
    cost 1
    language internal
as
$$icregexeqsel$$;

comment on function icregexeqsel(internal, oid, internal, integer) is 'restriction selectivity of case-insensitive regex match';

alter function icregexeqsel(internal, oid, internal, integer) owner to postgres;


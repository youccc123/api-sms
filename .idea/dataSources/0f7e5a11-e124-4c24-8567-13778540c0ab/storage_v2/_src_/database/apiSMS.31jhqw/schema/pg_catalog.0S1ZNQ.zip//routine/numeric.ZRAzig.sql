create function numeric(money) returns numeric
    immutable
    strict
    cost 1
    language internal
as
$$cash_numeric$$;

comment on function numeric(smallint, int4) is 'convert int2 to numeric';

alter function numeric(smallint, int4) owner to postgres;


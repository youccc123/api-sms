create function date(abstime) returns date
    stable
    strict
    cost 1
    language internal
as
$$abstime_date$$;

comment on function date(abstime) is 'convert abstime to date';

alter function date(abstime) owner to postgres;


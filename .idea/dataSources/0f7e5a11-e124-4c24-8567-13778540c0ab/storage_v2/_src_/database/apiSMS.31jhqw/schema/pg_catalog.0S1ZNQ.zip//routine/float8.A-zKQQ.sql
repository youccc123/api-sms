create function float8(smallint) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$i2tod$$;

comment on function float8(smallint) is 'convert int2 to float8';

alter function float8(smallint) owner to postgres;


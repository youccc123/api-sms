create function text(character) returns text
    immutable
    strict
    cost 1
    language internal
as
$$rtrim1$$;

comment on function text(char) is 'convert char(n) to text';

alter function text(char) owner to postgres;


create function pg_get_triggerdef(oid) returns text
    stable
    strict
    cost 1
    language internal
as
$$pg_get_triggerdef$$;

comment on function pg_get_triggerdef(oid, boolean) is 'trigger description with pretty-print option';

alter function pg_get_triggerdef(oid, boolean) owner to postgres;


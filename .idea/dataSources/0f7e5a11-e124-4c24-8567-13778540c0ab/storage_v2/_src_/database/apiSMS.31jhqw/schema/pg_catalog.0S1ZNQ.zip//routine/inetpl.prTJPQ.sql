create function inetpl(inet, bigint) returns inet
    immutable
    strict
    cost 1
    language internal
as
$$inetpl$$;

comment on function inetpl(inet, bigint) is 'implementation of + operator';

alter function inetpl(inet, bigint) owner to postgres;


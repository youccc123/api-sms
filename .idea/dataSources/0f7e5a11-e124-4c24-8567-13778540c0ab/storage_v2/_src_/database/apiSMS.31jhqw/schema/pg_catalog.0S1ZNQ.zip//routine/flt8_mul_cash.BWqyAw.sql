create function flt8_mul_cash(double precision, money) returns money
    immutable
    strict
    cost 1
    language internal
as
$$flt8_mul_cash$$;

comment on function flt8_mul_cash(double precision, money) is 'implementation of * operator';

alter function flt8_mul_cash(double precision, money) owner to postgres;


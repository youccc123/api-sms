create function round(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$dround$$;

comment on function round(double precision) is 'round to nearest integer';

alter function round(double precision) owner to postgres;


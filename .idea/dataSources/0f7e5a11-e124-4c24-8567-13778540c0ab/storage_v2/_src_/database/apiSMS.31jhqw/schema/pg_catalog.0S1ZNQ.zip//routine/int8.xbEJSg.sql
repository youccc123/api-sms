create function int8(integer) returns bigint
    immutable
    strict
    cost 1
    language internal
as
$$int48$$;

comment on function int8(bit) is 'convert bitstring to int8';

alter function int8(bit) owner to postgres;


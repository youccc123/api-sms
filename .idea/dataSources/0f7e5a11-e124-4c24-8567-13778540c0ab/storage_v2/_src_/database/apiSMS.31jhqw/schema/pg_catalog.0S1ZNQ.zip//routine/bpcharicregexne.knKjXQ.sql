create function bpcharicregexne(character, text) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$texticregexne$$;

comment on function bpcharicregexne(char, text) is 'implementation of !~* operator';

alter function bpcharicregexne(char, text) owner to postgres;


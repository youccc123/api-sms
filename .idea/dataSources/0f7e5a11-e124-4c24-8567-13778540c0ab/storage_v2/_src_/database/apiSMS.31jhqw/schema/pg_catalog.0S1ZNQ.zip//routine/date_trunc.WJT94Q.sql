create function date_trunc(text, timestamp without time zone) returns timestamp without time zone
    stable
    strict
    cost 1
    language internal
as
$$timestamp_trunc$$;

comment on function date_trunc(text, timestamp with time zone) is 'truncate timestamp with time zone to specified units';

alter function date_trunc(text, timestamp with time zone) owner to postgres;


create function isfinite(abstime) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$abstime_finite$$;

comment on function isfinite(interval) is 'finite interval?';

alter function isfinite(interval) owner to postgres;


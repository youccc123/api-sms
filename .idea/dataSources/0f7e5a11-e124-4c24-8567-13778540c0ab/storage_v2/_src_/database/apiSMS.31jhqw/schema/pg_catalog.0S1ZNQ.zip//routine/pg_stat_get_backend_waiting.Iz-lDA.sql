create function pg_stat_get_backend_waiting(integer) returns boolean
    stable
    strict
    cost 1
    language internal
as
$$pg_stat_get_backend_waiting$$;

comment on function pg_stat_get_backend_waiting(integer) is 'statistics: is backend currently waiting for a lock';

alter function pg_stat_get_backend_waiting(integer) owner to postgres;


create function gist_point_consistent(internal, point, integer, oid, internal) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$gist_point_consistent$$;

comment on function gist_point_consistent(internal, point, integer, oid, internal) is 'GiST support';

alter function gist_point_consistent(internal, point, integer, oid, internal) owner to postgres;


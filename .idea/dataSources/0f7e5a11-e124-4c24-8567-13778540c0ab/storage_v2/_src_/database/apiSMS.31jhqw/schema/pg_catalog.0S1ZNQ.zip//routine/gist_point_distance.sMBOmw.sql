create function gist_point_distance(internal, point, integer, oid) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$gist_point_distance$$;

comment on function gist_point_distance(internal, point, integer, oid) is 'GiST support';

alter function gist_point_distance(internal, point, integer, oid) owner to postgres;


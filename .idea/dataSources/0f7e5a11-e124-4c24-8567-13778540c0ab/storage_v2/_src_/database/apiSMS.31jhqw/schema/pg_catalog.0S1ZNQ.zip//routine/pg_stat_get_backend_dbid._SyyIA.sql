create function pg_stat_get_backend_dbid(integer) returns oid
    stable
    strict
    cost 1
    language internal
as
$$pg_stat_get_backend_dbid$$;

comment on function pg_stat_get_backend_dbid(integer) is 'statistics: database ID of backend';

alter function pg_stat_get_backend_dbid(integer) owner to postgres;


create function bool(integer) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$int4_bool$$;

comment on function bool(integer) is 'convert int4 to boolean';

alter function bool(integer) owner to postgres;


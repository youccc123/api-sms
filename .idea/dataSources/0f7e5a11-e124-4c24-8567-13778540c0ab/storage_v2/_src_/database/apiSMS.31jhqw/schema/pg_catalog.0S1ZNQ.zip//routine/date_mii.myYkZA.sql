create function date_mii(date, integer) returns date
    immutable
    strict
    cost 1
    language internal
as
$$date_mii$$;

comment on function date_mii(date, integer) is 'implementation of - operator';

alter function date_mii(date, integer) owner to postgres;


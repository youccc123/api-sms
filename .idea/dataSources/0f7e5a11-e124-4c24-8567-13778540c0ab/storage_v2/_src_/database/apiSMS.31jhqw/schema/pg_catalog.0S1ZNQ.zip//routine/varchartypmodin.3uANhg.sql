create function varchartypmodin(cstring[]) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$varchartypmodin$$;

comment on function varchartypmodin(cstring[]) is 'I/O typmod';

alter function varchartypmodin(cstring[]) owner to postgres;


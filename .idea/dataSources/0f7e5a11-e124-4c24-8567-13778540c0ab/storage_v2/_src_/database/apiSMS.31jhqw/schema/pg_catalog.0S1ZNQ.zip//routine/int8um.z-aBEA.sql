create function int8um(bigint) returns bigint
    immutable
    strict
    cost 1
    language internal
as
$$int8um$$;

comment on function int8um(bigint) is 'implementation of - operator';

alter function int8um(bigint) owner to postgres;


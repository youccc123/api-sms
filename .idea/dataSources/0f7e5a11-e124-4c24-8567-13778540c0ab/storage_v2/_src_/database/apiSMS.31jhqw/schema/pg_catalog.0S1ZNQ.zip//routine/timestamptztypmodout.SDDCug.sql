create function timestamptztypmodout(integer) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$timestamptztypmodout$$;

comment on function timestamptztypmodout(integer) is 'I/O typmod';

alter function timestamptztypmodout(integer) owner to postgres;


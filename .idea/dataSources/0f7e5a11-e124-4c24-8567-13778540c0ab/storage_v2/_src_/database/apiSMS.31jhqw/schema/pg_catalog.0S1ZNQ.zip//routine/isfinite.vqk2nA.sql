create function isfinite(abstime) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$abstime_finite$$;

comment on function isfinite(timestamp) is 'finite timestamp?';

alter function isfinite(timestamp) owner to postgres;


create function point(circle) returns point
    immutable
    strict
    cost 1
    language internal
as
$$circle_center$$;

comment on function point(lseg, float8) is 'center of';

alter function point(lseg, float8) owner to postgres;


create function log(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$dlog10$$;

comment on function log(double precision) is 'base 10 logarithm';

alter function log(double precision) owner to postgres;


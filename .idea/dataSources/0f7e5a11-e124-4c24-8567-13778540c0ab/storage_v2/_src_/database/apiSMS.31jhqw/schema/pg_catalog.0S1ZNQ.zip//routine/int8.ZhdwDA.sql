create function int8(integer) returns bigint
    immutable
    strict
    cost 1
    language internal
as
$$int48$$;

comment on function int8(real) is 'convert float4 to int8';

alter function int8(real) owner to postgres;


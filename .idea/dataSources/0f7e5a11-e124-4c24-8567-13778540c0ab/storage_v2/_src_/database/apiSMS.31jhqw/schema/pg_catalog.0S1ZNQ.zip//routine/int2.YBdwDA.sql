create function int2(double precision) returns smallint
    immutable
    strict
    cost 1
    language internal
as
$$dtoi2$$;

comment on function int2(real) is 'convert float4 to int2';

alter function int2(real) owner to postgres;


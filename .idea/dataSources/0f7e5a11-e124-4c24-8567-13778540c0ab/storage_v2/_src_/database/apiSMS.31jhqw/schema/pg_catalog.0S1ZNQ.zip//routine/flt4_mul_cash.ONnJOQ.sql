create function flt4_mul_cash(real, money) returns money
    immutable
    strict
    cost 1
    language internal
as
$$flt4_mul_cash$$;

comment on function flt4_mul_cash(real, money) is 'implementation of * operator';

alter function flt4_mul_cash(real, money) owner to postgres;


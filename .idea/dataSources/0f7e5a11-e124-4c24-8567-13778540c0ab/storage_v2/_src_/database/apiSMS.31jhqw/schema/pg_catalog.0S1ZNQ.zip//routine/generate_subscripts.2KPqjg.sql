create function generate_subscripts(anyarray, integer) returns SETOF integer
    immutable
    strict
    cost 1
    language internal
as
$$generate_subscripts_nodir$$;

comment on function generate_subscripts(anyarray, integer, bool) is 'array subscripts generator';

alter function generate_subscripts(anyarray, integer, bool) owner to postgres;


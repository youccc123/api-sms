create function isvertical(lseg) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$lseg_vertical$$;

comment on function isvertical(line, point) is 'vertical';

alter function isvertical(line, point) owner to postgres;


create function ltrim(text) returns text
    immutable
    strict
    cost 1
    language internal
as
$$ltrim1$$;

comment on function ltrim(text, text) is 'trim spaces from left end of string';

alter function ltrim(text, text) owner to postgres;


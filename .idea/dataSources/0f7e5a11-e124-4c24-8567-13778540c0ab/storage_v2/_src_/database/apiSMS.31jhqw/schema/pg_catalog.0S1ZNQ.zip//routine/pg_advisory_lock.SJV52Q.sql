create function pg_advisory_lock(bigint) returns void
    strict
    cost 1
    language internal
as
$$pg_advisory_lock_int8$$;

comment on function pg_advisory_lock(integer, integer) is 'obtain exclusive advisory lock';

alter function pg_advisory_lock(integer, integer) owner to postgres;


create function bpcharin(cstring, oid, integer) returns character
    immutable
    strict
    cost 1
    language internal
as
$$bpcharin$$;

comment on function bpcharin(cstring, oid, integer) is 'I/O';

alter function bpcharin(cstring, oid, integer) owner to postgres;


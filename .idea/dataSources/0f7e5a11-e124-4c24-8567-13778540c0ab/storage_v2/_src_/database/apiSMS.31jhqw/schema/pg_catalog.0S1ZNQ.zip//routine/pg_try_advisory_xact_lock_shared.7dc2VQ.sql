create function pg_try_advisory_xact_lock_shared(bigint) returns boolean
    strict
    cost 1
    language internal
as
$$pg_try_advisory_xact_lock_shared_int8$$;

comment on function pg_try_advisory_xact_lock_shared(integer, integer) is 'obtain shared advisory lock if available';

alter function pg_try_advisory_xact_lock_shared(integer, integer) owner to postgres;


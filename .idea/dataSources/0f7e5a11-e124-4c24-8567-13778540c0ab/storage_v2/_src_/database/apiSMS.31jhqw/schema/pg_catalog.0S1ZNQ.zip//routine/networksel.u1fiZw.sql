create function networksel(internal, oid, internal, integer) returns double precision
    stable
    strict
    cost 1
    language internal
as
$$networksel$$;

comment on function networksel(internal, oid, internal, integer) is 'restriction selectivity for network operators';

alter function networksel(internal, oid, internal, integer) owner to postgres;


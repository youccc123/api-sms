create function float8abs(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$float8abs$$;

comment on function float8abs(double precision) is 'implementation of @ operator';

alter function float8abs(double precision) owner to postgres;


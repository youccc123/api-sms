create function timetz_pl_interval(time with time zone, interval) returns time with time zone
    immutable
    strict
    cost 1
    language internal
as
$$timetz_pl_interval$$;

comment on function timetz_pl_interval(time with time zone, interval) is 'implementation of + operator';

alter function timetz_pl_interval(time with time zone, interval) owner to postgres;


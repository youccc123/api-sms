create function date(abstime) returns date
    stable
    strict
    cost 1
    language internal
as
$$abstime_date$$;

comment on function date(timestamp with time zone) is 'convert timestamp with time zone to date';

alter function date(timestamp with time zone) owner to postgres;


create function to_char(timestamp with time zone, text) returns text
    stable
    strict
    cost 1
    language internal
as
$$timestamptz_to_char$$;

comment on function to_char(timestamp with time zone, text) is 'format timestamp with time zone to text';

alter function to_char(timestamp with time zone, text) owner to postgres;


create function pg_advisory_xact_lock_shared(bigint) returns void
    strict
    cost 1
    language internal
as
$$pg_advisory_xact_lock_shared_int8$$;

comment on function pg_advisory_xact_lock_shared(bigint, int4) is 'obtain shared advisory lock';

alter function pg_advisory_xact_lock_shared(bigint, int4) owner to postgres;


create function timestamptz_pl_interval(timestamp with time zone, interval) returns timestamp with time zone
    stable
    strict
    cost 1
    language internal
as
$$timestamptz_pl_interval$$;

comment on function timestamptz_pl_interval(timestamp with time zone, interval) is 'implementation of + operator';

alter function timestamptz_pl_interval(timestamp with time zone, interval) owner to postgres;


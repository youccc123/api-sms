create function timestamptz(abstime) returns timestamp with time zone
    immutable
    strict
    cost 1
    language internal
as
$$abstime_timestamptz$$;

comment on function timestamptz(timestamp with time zone, integer) is 'adjust timestamptz precision';

alter function timestamptz(timestamp with time zone, integer) owner to postgres;


create function substr(text, integer, integer) returns text
    immutable
    strict
    cost 1
    language internal
as
$$text_substr$$;

comment on function substr(bytea, integer, integer) is 'extract portion of string';

alter function substr(bytea, integer, integer) owner to postgres;


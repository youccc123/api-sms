create function pg_encoding_to_char(integer) returns name
    stable
    strict
    cost 1
    language internal
as
$$PG_encoding_to_char$$;

comment on function pg_encoding_to_char(integer) is 'convert encoding id to encoding name';

alter function pg_encoding_to_char(integer) owner to postgres;


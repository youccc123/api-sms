create function areasel(internal, oid, internal, integer) returns double precision
    stable
    strict
    cost 1
    language internal
as
$$areasel$$;

comment on function areasel(internal, oid, internal, integer) is 'restriction selectivity for area-comparison operators';

alter function areasel(internal, oid, internal, integer) owner to postgres;


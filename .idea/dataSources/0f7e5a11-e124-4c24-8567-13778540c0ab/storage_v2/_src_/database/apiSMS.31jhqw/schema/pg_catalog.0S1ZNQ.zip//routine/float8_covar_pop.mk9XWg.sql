create function float8_covar_pop(double precision[]) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$float8_covar_pop$$;

comment on function float8_covar_pop(double precision[]) is 'aggregate final function';

alter function float8_covar_pop(double precision[]) owner to postgres;


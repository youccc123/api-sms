create function cash_div_int4(money, integer) returns money
    immutable
    strict
    cost 1
    language internal
as
$$cash_div_int4$$;

comment on function cash_div_int4(money, integer) is 'implementation of / operator';

alter function cash_div_int4(money, integer) owner to postgres;


create function pg_get_constraintdef(oid) returns text
    stable
    strict
    cost 1
    language internal
as
$$pg_get_constraintdef$$;

comment on function pg_get_constraintdef(oid, boolean) is 'constraint description with pretty-print option';

alter function pg_get_constraintdef(oid, boolean) owner to postgres;


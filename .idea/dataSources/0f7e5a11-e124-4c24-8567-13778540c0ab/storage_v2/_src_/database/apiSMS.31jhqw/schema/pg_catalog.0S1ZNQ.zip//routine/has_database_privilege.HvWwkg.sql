create function has_database_privilege(name, text, text) returns boolean
    stable
    strict
    cost 1
    language internal
as
$$has_database_privilege_name_name$$;

comment on function has_database_privilege(text, text, text) is 'current user privilege on database by database name';

alter function has_database_privilege(text, text, text) owner to postgres;


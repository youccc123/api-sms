create function cash_div_int2(money, smallint) returns money
    immutable
    strict
    cost 1
    language internal
as
$$cash_div_int2$$;

comment on function cash_div_int2(money, smallint) is 'implementation of / operator';

alter function cash_div_int2(money, smallint) owner to postgres;


create function timestamptz(abstime) returns timestamp with time zone
    immutable
    strict
    cost 1
    language internal
as
$$abstime_timestamptz$$;

comment on function timestamptz(date, time with time zone) is 'convert date and time with time zone to timestamp with time zone';

alter function timestamptz(date, time with time zone) owner to postgres;


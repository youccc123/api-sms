create function bpcharregexne(character, text) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$textregexne$$;

comment on function bpcharregexne(char, text) is 'implementation of !~ operator';

alter function bpcharregexne(char, text) owner to postgres;


create function factorial(bigint) returns numeric
    immutable
    strict
    cost 1
    language internal
as
$$numeric_fac$$;

comment on function factorial(bigint) is 'factorial';

alter function factorial(bigint) owner to postgres;


create function timetztypmodin(cstring[]) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$timetztypmodin$$;

comment on function timetztypmodin(cstring[]) is 'I/O typmod';

alter function timetztypmodin(cstring[]) owner to postgres;


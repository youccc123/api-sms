create function timestamp_ge_timestamptz(timestamp without time zone, timestamp with time zone) returns boolean
    stable
    strict
    cost 1
    language internal
as
$$timestamp_ge_timestamptz$$;

comment on function timestamp_ge_timestamptz(timestamp, timestamp with time zone) is 'implementation of >= operator';

alter function timestamp_ge_timestamptz(timestamp, timestamp with time zone) owner to postgres;


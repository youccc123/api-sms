create function timestamp(timestamp without time zone, integer) returns timestamp without time zone
    stable
    strict
    cost 1
    language internal
as
$$timestamp_scale$$;

comment on function timestamp(abstime) is 'convert abstime to timestamp';

alter function timestamp(abstime) owner to postgres;


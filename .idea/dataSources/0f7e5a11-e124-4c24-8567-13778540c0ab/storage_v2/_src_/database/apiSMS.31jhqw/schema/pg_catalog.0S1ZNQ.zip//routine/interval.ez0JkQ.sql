create function interval(reltime) returns interval
    immutable
    strict
    cost 1
    language internal
as
$$reltime_interval$$;

comment on function interval(interval, integer) is 'adjust interval precision';

alter function interval(interval, integer) owner to postgres;


create function timetztypmodout(integer) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$timetztypmodout$$;

comment on function timetztypmodout(integer) is 'I/O typmod';

alter function timetztypmodout(integer) owner to postgres;


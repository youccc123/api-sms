create function ceil(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$dceil$$;

comment on function ceil(double precision) is 'smallest integer >= value';

alter function ceil(double precision) owner to postgres;


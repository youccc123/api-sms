create function int8up(bigint) returns bigint
    immutable
    strict
    cost 1
    language internal
as
$$int8up$$;

comment on function int8up(bigint) is 'implementation of + operator';

alter function int8up(bigint) owner to postgres;


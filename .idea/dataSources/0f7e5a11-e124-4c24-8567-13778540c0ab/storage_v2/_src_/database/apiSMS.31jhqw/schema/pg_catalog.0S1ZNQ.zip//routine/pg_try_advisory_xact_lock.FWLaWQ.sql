create function pg_try_advisory_xact_lock(bigint) returns boolean
    strict
    cost 1
    language internal
as
$$pg_try_advisory_xact_lock_int8$$;

comment on function pg_try_advisory_xact_lock(integer, integer) is 'obtain exclusive advisory lock if available';

alter function pg_try_advisory_xact_lock(integer, integer) owner to postgres;


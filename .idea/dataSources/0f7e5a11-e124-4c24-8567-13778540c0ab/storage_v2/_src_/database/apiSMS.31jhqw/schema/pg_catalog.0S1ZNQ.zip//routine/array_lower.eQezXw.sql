create function array_lower(anyarray, integer) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$array_lower$$;

comment on function array_lower(anyarray, integer) is 'array lower dimension';

alter function array_lower(anyarray, integer) owner to postgres;


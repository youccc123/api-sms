create function scalargtjoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    cost 1
    language internal
as
$$scalargtjoinsel$$;

comment on function scalargtjoinsel(internal, oid, internal, smallint, internal) is 'join selectivity of > and related operators on scalar datatypes';

alter function scalargtjoinsel(internal, oid, internal, smallint, internal) owner to postgres;


create function has_language_privilege(name, text, text) returns boolean
    stable
    strict
    cost 1
    language internal
as
$$has_language_privilege_name_name$$;

comment on function has_language_privilege(text, text, text) is 'current user privilege on language by language name';

alter function has_language_privilege(text, text, text) owner to postgres;


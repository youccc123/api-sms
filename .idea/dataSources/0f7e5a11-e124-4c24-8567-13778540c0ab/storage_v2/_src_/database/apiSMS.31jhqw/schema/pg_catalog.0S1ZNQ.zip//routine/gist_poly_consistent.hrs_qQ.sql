create function gist_poly_consistent(internal, polygon, integer, oid, internal) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$gist_poly_consistent$$;

comment on function gist_poly_consistent(internal, polygon, integer, oid, internal) is 'GiST support';

alter function gist_poly_consistent(internal, polygon, integer, oid, internal) owner to postgres;


create function neqsel(internal, oid, internal, integer) returns double precision
    stable
    strict
    cost 1
    language internal
as
$$neqsel$$;

comment on function neqsel(internal, oid, internal, integer) is 'restriction selectivity of <> and related operators';

alter function neqsel(internal, oid, internal, integer) owner to postgres;


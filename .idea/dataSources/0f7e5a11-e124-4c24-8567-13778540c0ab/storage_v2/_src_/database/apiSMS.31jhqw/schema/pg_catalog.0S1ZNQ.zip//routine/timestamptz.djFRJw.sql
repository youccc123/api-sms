create function timestamptz(abstime) returns timestamp with time zone
    stable
    strict
    cost 1
    language internal
as
$$abstime_timestamptz$$;

comment on function timestamptz(timestamp, int4) is 'convert timestamp to timestamp with time zone';

alter function timestamptz(timestamp, int4) owner to postgres;


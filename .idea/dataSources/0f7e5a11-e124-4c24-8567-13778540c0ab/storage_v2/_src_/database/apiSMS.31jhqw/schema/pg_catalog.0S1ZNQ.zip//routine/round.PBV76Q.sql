create function round(double precision) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$dround$$;

comment on function round(numeric, integer) is 'value rounded to ''scale''';

alter function round(numeric, integer) owner to postgres;


create function float8(smallint) returns double precision
    immutable
    strict
    cost 1
    language internal
as
$$i2tod$$;

comment on function float8(bigint) is 'convert int8 to float8';

alter function float8(bigint) owner to postgres;


create function overlay(bytea, bytea, integer, integer) returns bytea
    immutable
    strict
    cost 1
    language internal
as
$$byteaoverlay$$;

comment on function overlay(bit, bit, integer, int4) is 'substitute portion of bitstring';

alter function overlay(bit, bit, integer, int4) owner to postgres;


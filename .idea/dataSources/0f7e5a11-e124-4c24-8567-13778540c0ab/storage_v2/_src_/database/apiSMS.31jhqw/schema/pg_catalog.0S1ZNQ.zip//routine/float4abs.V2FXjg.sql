create function float4abs(real) returns real
    immutable
    strict
    cost 1
    language internal
as
$$float4abs$$;

comment on function float4abs(real) is 'implementation of @ operator';

alter function float4abs(real) owner to postgres;


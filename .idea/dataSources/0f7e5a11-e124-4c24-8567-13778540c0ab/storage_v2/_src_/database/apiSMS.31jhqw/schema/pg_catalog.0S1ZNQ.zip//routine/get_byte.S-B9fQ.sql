create function get_byte(bytea, integer) returns integer
    immutable
    strict
    cost 1
    language internal
as
$$byteaGetByte$$;

comment on function get_byte(bytea, integer) is 'get byte';

alter function get_byte(bytea, integer) owner to postgres;


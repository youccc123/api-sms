create function float4out(real) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$float4out$$;

comment on function float4out(real) is 'I/O';

alter function float4out(real) owner to postgres;


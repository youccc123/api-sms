create function contjoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    cost 1
    language internal
as
$$contjoinsel$$;

comment on function contjoinsel(internal, oid, internal, smallint, internal) is 'join selectivity for containment comparison operators';

alter function contjoinsel(internal, oid, internal, smallint, internal) owner to postgres;


create function int2not(smallint) returns smallint
    immutable
    strict
    cost 1
    language internal
as
$$int2not$$;

comment on function int2not(smallint) is 'implementation of ~ operator';

alter function int2not(smallint) owner to postgres;


create function ginarrayextract(anyarray, internal) returns internal
    immutable
    strict
    cost 1
    language internal
as
$$ginarrayextract_2args$$;

comment on function ginarrayextract(anyarray, internal, internal) is 'GIN array support (obsolete)';

alter function ginarrayextract(anyarray, internal, internal) owner to postgres;


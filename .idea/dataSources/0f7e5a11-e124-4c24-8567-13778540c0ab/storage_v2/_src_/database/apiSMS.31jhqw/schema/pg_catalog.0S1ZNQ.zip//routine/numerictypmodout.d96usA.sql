create function numerictypmodout(integer) returns cstring
    immutable
    strict
    cost 1
    language internal
as
$$numerictypmodout$$;

comment on function numerictypmodout(integer) is 'I/O typmod';

alter function numerictypmodout(integer) owner to postgres;


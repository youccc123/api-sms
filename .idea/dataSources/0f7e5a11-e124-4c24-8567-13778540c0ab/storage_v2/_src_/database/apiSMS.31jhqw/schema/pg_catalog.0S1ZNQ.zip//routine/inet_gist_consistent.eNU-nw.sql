create function inet_gist_consistent(internal, inet, integer, oid, internal) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$inet_gist_consistent$$;

comment on function inet_gist_consistent(internal, inet, integer, oid, internal) is 'GiST support';

alter function inet_gist_consistent(internal, inet, integer, oid, internal) owner to postgres;


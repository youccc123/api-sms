create function int4("char") returns integer
    immutable
    strict
    cost 1
    language internal
as
$$chartoi4$$;

comment on function int4(smallint) is 'convert int2 to int4';

alter function int4(smallint) owner to postgres;


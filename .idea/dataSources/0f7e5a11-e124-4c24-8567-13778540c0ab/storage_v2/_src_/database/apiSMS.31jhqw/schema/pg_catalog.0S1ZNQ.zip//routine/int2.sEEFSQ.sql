create function int2(double precision) returns smallint
    immutable
    strict
    cost 1
    language internal
as
$$dtoi2$$;

comment on function int2(integer) is 'convert int4 to int2';

alter function int2(integer) owner to postgres;


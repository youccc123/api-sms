create function pg_get_viewdef(text) returns text
    stable
    strict
    cost 1
    language internal
as
$$pg_get_viewdef_name$$;

comment on function pg_get_viewdef(oid, boolean) is 'select statement of a view with pretty-print option';

alter function pg_get_viewdef(oid, boolean) owner to postgres;


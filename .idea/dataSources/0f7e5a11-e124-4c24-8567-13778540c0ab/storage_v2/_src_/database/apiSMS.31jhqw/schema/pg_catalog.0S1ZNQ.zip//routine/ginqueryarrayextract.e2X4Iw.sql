create function ginqueryarrayextract(anyarray, internal, smallint, internal, internal, internal, internal) returns internal
    immutable
    strict
    cost 1
    language internal
as
$$ginqueryarrayextract$$;

comment on function ginqueryarrayextract(anyarray, internal, smallint, internal, internal, internal, internal) is 'GIN array support';

alter function ginqueryarrayextract(anyarray, internal, smallint, internal, internal, internal, internal) owner to postgres;


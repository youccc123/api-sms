create function gist_circle_consistent(internal, circle, integer, oid, internal) returns boolean
    immutable
    strict
    cost 1
    language internal
as
$$gist_circle_consistent$$;

comment on function gist_circle_consistent(internal, circle, integer, oid, internal) is 'GiST support';

alter function gist_circle_consistent(internal, circle, integer, oid, internal) owner to postgres;


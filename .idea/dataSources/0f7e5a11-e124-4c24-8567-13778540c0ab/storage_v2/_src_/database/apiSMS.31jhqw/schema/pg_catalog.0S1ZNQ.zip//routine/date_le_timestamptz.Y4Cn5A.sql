create function date_le_timestamptz(date, timestamp with time zone) returns boolean
    stable
    strict
    cost 1
    language internal
as
$$date_le_timestamptz$$;

comment on function date_le_timestamptz(date, timestamp with time zone) is 'implementation of <= operator';

alter function date_le_timestamptz(date, timestamp with time zone) owner to postgres;


create function has_tablespace_privilege(name, text, text) returns boolean
    stable
    strict
    cost 1
    language internal
as
$$has_tablespace_privilege_name_name$$;

comment on function has_tablespace_privilege(text, text, text) is 'current user privilege on tablespace by tablespace name';

alter function has_tablespace_privilege(text, text, text) owner to postgres;

